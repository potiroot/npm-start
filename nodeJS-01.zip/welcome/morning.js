module.exports = 'Доброе утро';
