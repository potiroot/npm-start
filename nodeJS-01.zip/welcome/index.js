// const morning = require('./morning');
// const evening = require('./evening');
//
// module.exports = {
// 	getMorningMessage: function () {
// 		console.log(morning);
// 	},
// 	getEveningMessage: function () {
// 		console.log(evening);
// 	},
// };

const greeting = require('./greeting');

global.name = 'Edgar';

global.console.log(date);
global.console.log(greeting.getMessage());
