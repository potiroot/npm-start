function User(name, age, education) {
	this.name = name;
	this.age = age;
	this.education = education;
	this.displayInfo = function () {
		console.log(`Имя: ${this.name}\nВозраст: ${this.age}\nОбразование: ${this.education}`);
	};
}

module.exports = User;
